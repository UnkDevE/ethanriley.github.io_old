/*global Sass*/
var Module = {
  onRuntimeInitialized: function() {
    'use strict';
    Sass._ready();
  }
};
